package com.rief.github.view.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.rief.github.data.model.database.FavoriteUser
import com.rief.github.data.model.database.FavoriteUserDAO
import com.rief.github.data.model.database.UserDatabase
import com.rief.github.data.model.response.DetailUserResponse

class FavoriteViewModel (application: Application) : AndroidViewModel (application){
	val user = MutableLiveData<DetailUserResponse>()
	val stateLoad = MutableLiveData<Boolean>()
	
	private var userDao : FavoriteUserDAO?
	private var userDb : UserDatabase?
	
	init {
		userDb = UserDatabase.getDatabase(application)
		userDao = userDb?.favoriteUserDao()
	}
	
	fun getFavoriteUser() : LiveData<List<FavoriteUser>>? {
		return userDao?.getFavoriteUser()
	}
}