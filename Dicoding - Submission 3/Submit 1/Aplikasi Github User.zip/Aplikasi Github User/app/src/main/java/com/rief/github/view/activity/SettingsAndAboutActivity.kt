package com.rief.github.view.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.app.AppCompatDelegate
import com.rief.databinding.ActivitySettingsAndAboutBinding

class SettingAndAboutActivity : AppCompatActivity() {
	
	private lateinit var binding : ActivitySettingsAndAboutBinding
	
	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		binding = ActivitySettingsAndAboutBinding.inflate(layoutInflater)
		setContentView(binding.root)
		
		supportActionBar!!.title = "Settings And About"
		
		val mode1 = "Night"
		val mode2 = "Light"
		
		binding.btnSwitch.setOnCheckedChangeListener { _, isChecked ->
			when(isChecked){
				true -> {
					binding.tvMode.text = mode1
					AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
				}
				false -> {
					binding.tvMode.text = mode2
					AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
				}
			}
		}
	}
}