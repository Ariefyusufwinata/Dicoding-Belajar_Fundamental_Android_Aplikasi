package com.rief.github.data.model.response

import com.rief.github.data.model.User

data class UserResponse (
    val items : ArrayList<User>
)