package com.rief.github.data.model

data class User(
    val login: String?,
    val avatar_url: String?,
    val id: Int?
)