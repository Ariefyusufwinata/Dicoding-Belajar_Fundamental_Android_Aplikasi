package com.rief.adapter

import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.rief.fragment.FollowersFragment
import com.rief.fragment.FollowingFragments

//class ViewPagerAdapter(private val context : Context, fm : FragmentManager, data : Bundle) : FragmentPagerAdapter(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT) {
//	private var containerFragment : Bundle = data
//	private val tabLayoutTittles = intArrayOf(R.string.tab1, R.string.tab2)
//	override fun getCount(): Int = 2
//
//	override fun getItem(position: Int): Fragment {
//		var fragment: Fragment? = null
//		when(position){
//			0 -> fragment = FollowersFragment()
//			1 -> fragment = FollowingFragments()
//		}
//		fragment?.arguments = this.containerFragment
//		return fragment as Fragment
//	}
//
//	override fun getPageTitle(position: Int): CharSequence {
//		return context.resources.getString(tabLayoutTittles[position])
//	}
//
//}

class ViewPagerAdapter(appCompatActivity: AppCompatActivity) : FragmentStateAdapter(appCompatActivity){

	private val listFragment : List<Fragment> =
		listOf(
			FollowersFragment(),
			FollowingFragments()
		)
	
	override fun getItemCount(): Int = listFragment.size
	override fun createFragment(position: Int): Fragment = listFragment[position]
}